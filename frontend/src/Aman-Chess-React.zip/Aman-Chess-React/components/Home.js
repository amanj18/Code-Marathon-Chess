import React from 'react';

const Home = () => {
  return (
    <>
      <h1>Home</h1>
          <img
            className="d-block w-100"
            src="https://media.gettyimages.com/id/157280858/photo/king-and-servants.jpg?s=612x612&w=0&k=20&c=xCttOgtvet0LFeay6eW_byNXvQBuGnvW9Z3CeV3mMjQ=" width="800px" height="400px"
            alt="First slide"
          />
    </>
  );
};

export default Home;