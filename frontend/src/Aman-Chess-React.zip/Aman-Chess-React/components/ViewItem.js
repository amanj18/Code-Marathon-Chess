import React from 'react'
import PlayerCards from './PlayerCard.js';

const ViewItem = () => {
  return (
    <>
    <h1>Player Details</h1>
    <PlayerCards />
  </>
  )
}

export default ViewItem;